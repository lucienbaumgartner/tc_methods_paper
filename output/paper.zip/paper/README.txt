- paper_study2_class_membership_MNL.pdf : These are the results of the multinomial logit model. The first 5 facets are single plots for the classes, the sixth is a combined plot without confidence intervals.

- paper_study2_EvalvsNonEval_logit.pdf : These are the probabilities for an adjective of being EVALUATIVE compared to NON-EVALUATIVE based on its eval-value (logit model)

- paper_study1_distributions_per_target.csv : Distribution indicators for all target adjectives (25%-, 50%- (median), and 75%-quantile and mean)

- paper_study1_univariate_kmeans_clustering.txt : both the concept class fidelity and cluster purity/composition. I'd use the concept class fidelity for the paper.

- paper_study2_dendogramm.pdf : I added the color-coding

- paper_study1_results.txt : this one changed quite a bit and I also added new contrasts, since in our discussions we were discussing mostly the contrast between TC/thin (evaluative) and VAC/DC (non-evaluative). Interestingly, we actually are able to distinguish evaluative and non-evaluative concepts. In the file you find the different contrasts. We need to select one of the results to include as the primary result. It depends a bit on the statement we want to make: 
	- if we are primarily interested in VAC vs evaluative concepts, I'd include the last contrasts (1x2x2 ANOVA: VAC vs all evaluative classes by polarity)
	- if we want a more finegrained result, we can choose any of the other.
		
